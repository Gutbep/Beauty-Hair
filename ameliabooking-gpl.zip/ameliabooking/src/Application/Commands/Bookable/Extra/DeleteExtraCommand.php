<?php

namespace AmeliaBooking\Application\Commands\Bookable\Extra;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class DeleteExtraCommand
 *
 * @package AmeliaBooking\Application\Commands\Bookable\Extra
 */
class DeleteExtraCommand extends Command
{

}
