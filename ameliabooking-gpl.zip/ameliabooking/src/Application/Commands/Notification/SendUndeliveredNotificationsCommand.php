<?php

namespace AmeliaBooking\Application\Commands\Notification;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class SendUndeliveredNotificationsCommand
 *
 * @package AmeliaBooking\Application\Commands\Notification
 */
class SendUndeliveredNotificationsCommand extends Command
{

}
