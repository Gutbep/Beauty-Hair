<?php

namespace AmeliaBooking\Application\Commands\Booking\Appointment;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class DeleteBookingCommand
 *
 * @package AmeliaBooking\Application\Commands\Booking\Appointment
 */
class DeleteBookingCommand extends Command
{

}
