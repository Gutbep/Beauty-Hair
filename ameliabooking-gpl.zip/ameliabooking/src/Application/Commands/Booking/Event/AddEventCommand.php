<?php

namespace AmeliaBooking\Application\Commands\Booking\Event;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class AddEventCommand
 *
 * @package AmeliaBooking\Application\Commands\Booking\Event
 */
class AddEventCommand extends Command
{

}
