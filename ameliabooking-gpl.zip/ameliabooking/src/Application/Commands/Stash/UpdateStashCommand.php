<?php
/**
 * @copyright © TMS-Plugins. All rights reserved.
 * @licence   See LICENCE.md for license details.
 */

namespace AmeliaBooking\Application\Commands\Stash;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class UpdateStashCommand
 *
 * @package AmeliaBooking\Application\Commands\Stash
 */
class UpdateStashCommand extends Command
{

}
