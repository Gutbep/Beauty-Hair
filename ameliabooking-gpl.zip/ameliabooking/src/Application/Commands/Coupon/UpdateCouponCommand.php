<?php
/**
 * @copyright © TMS-Plugins. All rights reserved.
 * @licence   See LICENCE.md for license details.
 */

namespace AmeliaBooking\Application\Commands\Coupon;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class UpdateCouponCommand
 *
 * @package AmeliaBooking\Application\Commands\Coupon
 */
class UpdateCouponCommand extends Command
{

}
