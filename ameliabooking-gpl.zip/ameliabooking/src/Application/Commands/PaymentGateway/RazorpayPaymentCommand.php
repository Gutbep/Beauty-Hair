<?php

namespace AmeliaBooking\Application\Commands\PaymentGateway;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class RazorpayPaymentCommand
 *
 * @package AmeliaBooking\Application\Commands\PaymentGateway
 */
class RazorpayPaymentCommand extends Command
{

}
