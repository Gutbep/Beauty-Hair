<?php
/**
 * @copyright © TMS-Plugins. All rights reserved.
 * @licence   See LICENCE.md for license details.
 */

namespace AmeliaBooking\Application\Commands\Report;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class GetCustomersCommand
 *
 * @package AmeliaBooking\Application\Commands\Report
 */
class GetCustomersCommand extends Command
{

}
