<?php

namespace AmeliaBooking\Application\Commands\Location;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class UpdateLocationCommand
 *
 * @package AmeliaBooking\Application\Commands\Location
 */
class UpdateLocationCommand extends Command
{

    /**
     * UpdateLocationCommand constructor.
     *
     * @param $args
     */
    public function __construct($args)
    {
        parent::__construct($args);
    }
}
