<?php

namespace AmeliaBooking\Application\Commands\CustomField;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class AddCustomFieldCommand
 *
 * @package AmeliaBooking\Application\Commands\CustomField
 */
class AddCustomFieldCommand extends Command
{

}
