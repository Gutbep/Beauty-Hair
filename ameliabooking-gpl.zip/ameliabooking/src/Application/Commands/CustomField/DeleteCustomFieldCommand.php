<?php

namespace AmeliaBooking\Application\Commands\CustomField;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class DeleteCustomFieldCommand
 *
 * @package AmeliaBooking\Application\Commands\CustomField
 */
class DeleteCustomFieldCommand extends Command
{

}
